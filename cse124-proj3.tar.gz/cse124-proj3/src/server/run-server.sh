#!/bin/bash

java -cp /usr/local/lib/slf4j-api-1.7.10.jar:/usr/local/lib/slf4j-simple-1.7.10.jar:/usr/share/java/thrift-0.9.0.jar:TwitterServer.jar edu.ucsd.cse124.TwitterServer
